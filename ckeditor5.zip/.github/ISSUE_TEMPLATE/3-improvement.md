---
name: "💅 Improvement"
about: Improve an existing functionality.
title: ''
labels: type:improvement
assignees: ''

---

## 📝 Provide a description of the improvement

_How the feature works now and what you'd like to change_?

## 📃 Other details

* Browser: …
* OS: …
* CKEditor version: …
* Installed CKEditor plugins: …

---

If you'd like to see this improvement implemented, add a 👍 reaction to this post.
