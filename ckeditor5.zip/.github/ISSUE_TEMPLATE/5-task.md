---
name: "\U0001F477 Task"
about: It's neither a bug nor a feature request.
title: ''
labels: type:task
assignees: ''

---

## Provide a description of the task

_What steps should be taken to fulfill the task?_

## 📃 Other details

* Browser: …
* OS: …
* CKEditor version: …
* Installed CKEditor plugins: …
