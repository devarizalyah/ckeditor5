---
category: examples-builds
order: 20
classes: main__content--no-toc
---

# Inline editor

{@link builds/guides/overview#inline-editor Inline editor} lets you create your content directly in its target location with the help of a floating toolbar that apprears when the editable text is focused.

In this example the {@link features/image#image-styles image styles} configuration was changed to enable left- and right-aligned images.

{@snippet examples/inline-editor}
