---
# Scope:
# * Explain browser compatibility of CKEditor 5.
# * Document known compatibility issues and missing features.
# * Discuss support for mobile environments.

category: framework-support
order: 10
title: Browser compatibility
---

{@importguide builds/guides/support/browser-compatibility}
