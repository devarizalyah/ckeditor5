Changelog
=========

All changes in the package are documented in the main repository. See: https://github.com/ckeditor/ckeditor5/blob/master/CHANGELOG.md.

Changes for the past releases are available below.

## [19.0.0](https://github.com/ckeditor/ckeditor-cloud-services-core/compare/v18.0.0...v19.0.0) (2020-04-29)

### Features

* Exposed the `refreshToken` method. ([013b89e](https://github.com/ckeditor/ckeditor-cloud-services-core/commit/013b89e))


## [18.0.0](https://github.com/ckeditor/ckeditor-cloud-services-core/compare/v17.0.0...v18.0.0) (2020-03-19)

Internal changes only (updated dependencies, documentation, etc.).


## [17.0.0](https://github.com/ckeditor/ckeditor-cloud-services-core/compare/v16.0.0...v17.0.0) (2020-02-18)

Internal changes only (updated dependencies, documentation, etc.).


## [16.0.0](https://github.com/ckeditor/ckeditor-cloud-services-core/compare/v15.0.0...v16.0.0) (2019-12-04)

Internal changes only (updated dependencies, documentation, etc.).


## [15.0.0](https://github.com/ckeditor/ckeditor-cloud-services-core/compare/v3.0.1...v15.0.0) (2019-10-23)

First release tracked in the changelog.
