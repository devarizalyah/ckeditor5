CKEditor Cloud Services Core
============================

[![npm version](https://badge.fury.io/js/%40ckeditor%2Fckeditor-cloud-services-core.svg)](https://www.npmjs.com/package/@ckeditor/ckeditor-cloud-services-core)
[![Dependency Status](https://david-dm.org/ckeditor/ckeditor-cloud-services-core/status.svg)](https://david-dm.org/ckeditor/ckeditor-cloud-services-core)
[![devDependency Status](https://david-dm.org/ckeditor/ckeditor-cloud-services-core/dev-status.svg)](https://david-dm.org/ckeditor/ckeditor-cloud-services-core?type=dev)

## Documentation

See the [`@ckeditor/ckeditor-cloud-services-core` package](https://ckeditor.com/docs/ckeditor5/latest/api/cloud-services-core.html) page in [CKEditor 5 documentation](https://ckeditor.com/docs/ckeditor5/latest/).

## License

Licensed under the terms of [GNU General Public License Version 2 or later](http://www.gnu.org/licenses/gpl.html). For full details about the license, please check the `LICENSE.md` file or [https://ckeditor.com/legal/ckeditor-oss-license](https://ckeditor.com/legal/ckeditor-oss-license).
