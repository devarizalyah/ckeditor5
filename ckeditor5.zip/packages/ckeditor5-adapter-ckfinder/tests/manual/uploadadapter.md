## CKFinder upload adapter

1. Drop an image into editor.
1. Image should be read and displayed.
1. Upload progress bar should be visible above the image.
1. After uploading is complete your image should be replaced with sample image from server (use dev tools to check image src attribute).

Repeat all the steps with:
* dropping multiple images,
* using toolbar button to add one and multiple images.
