# CKEditor 5 document editor build – standard version

Just play with it.

**Note:** Remember to rebuild the bundles (`npm run build`). You can also run Webpack in the watch mode:

```
./node_modules/.bin/webpack -w
```
