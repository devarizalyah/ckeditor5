### CKFinder sample

1. Use the toolbar icon insert an image.
1. Use the toolbar icon insert link to a non-image file.
1. Use the button below the editor to change opener method to "popup" and repeat steps 1-2.
