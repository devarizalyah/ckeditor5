## Copy and cut

Play with copy and cut. Paste copied content.

Compare the results with the native editable. Don't expect that they behave identically. Check plain text pasting
(for example paste editor content to code editor).
