## Pasting

Simply test pasting various content to the editor.

Check:

1. Copy & paste within the editor (nothing should be filtered out, nothing should be lost).
2. ~~Pasting from some websites (editor should not blow up).~~ (not yet stable)

Note:

* In Safari, only plain text is pasted.
