## Code blocks and RTL content

1. The code in all blocks should be left aligned.
2. The code should have a left–to–right direction (so `foo()`, not `()foo`).
3. The label describing the used language should be in the upper right corner of each block.
